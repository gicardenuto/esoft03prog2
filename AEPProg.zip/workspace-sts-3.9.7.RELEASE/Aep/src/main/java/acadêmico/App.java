package acadêmico;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class App {
	public static void main(String[] args) {
		Random rand = new Random(System.currentTimeMillis());
		String[] nomeAlunos = {
				"Maria", "Pedro", "Thiago", "Andre", "João",
				"Lucas", "Carlos", "Jose", "Fabio", "Jorge"
		};
		String[] disciplinaNomes = {"Português", "Matemática", "Física", "Historia", "Ciências"};
		List<Disciplina> disciplinas = new ArrayList<Disciplina>();
		RepositorioDeAvaliacoes rep = new RepositorioDeAvaliacoes();
		
		for (String disciplina: disciplinaNomes) disciplinas.add(new Disciplina(disciplina));
		
	
		for (int i = 0; i < disciplinas.size(); i++) {
			int numeroReprovados = 0;
			
			for (int j = 0; j < nomeAlunos.length; j++) {
				Aluno aluno = new Aluno(nomeAlunos[j], Math.abs(rand.nextInt()));
				boolean reprovado = (rand.nextInt() % 2 == 0) && (numeroReprovados < i);
				if (numeroReprovados < i && j > 5) reprovado = true;
				if (reprovado) numeroReprovados++;
				
				List<Float> notas = (reprovado) ? gerarReprovado() : gerarAprovado();
				
				
				
				for (Float nota: notas) {
					Avaliacao avaliacao = new Avaliacao(nota, disciplinas.get(i), aluno);
					rep.adicionarAvaliacao(avaliacao);
				}
			}
		
		}
		
		for (Disciplina disciplina: disciplinas) {
			System.out.println("Nome da disciplina: " + disciplina.getNome());
			rep.obterAprovados(disciplina, true);
			System.out.println("");
		}
		
		for (Disciplina disciplina: disciplinas) {
			System.out.println("Nome da disciplina: " + disciplina.getNome());
			System.out.println("Aprovados: " + rep.obterAprovados(disciplina, false).size());
		}
	}
	
	
	public static List<Float> gerarReprovado() {
		List<Float> notas = new ArrayList<Float>();
		do {
			notas.clear();
			for (int i = 0; i < 4; i++) notas.add((float)Math.ceil(Math.random() * 10));
		}
		while(calcularMedia(notas) >= 6);
		
		return notas;
	}
	
	
	public static List<Float> gerarAprovado() {
		List<Float> notas = new ArrayList<Float>();
		do {
			notas.clear();
			for (int i = 0; i < 4; i++) notas.add((float)Math.ceil(Math.random() * 10));
		}
		while(calcularMedia(notas) < 6);
		
		return notas;
	}
	
	
	public static Float calcularMedia(List<Float> arr) {
		Float soma = (float)0;
		for (int i = 0; i < arr.size(); i++) soma += arr.get(i);
		return soma / arr.size();
	}
}
		
	
	