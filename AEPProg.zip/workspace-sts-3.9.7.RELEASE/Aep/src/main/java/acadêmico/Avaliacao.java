package acadêmico;

public class Avaliacao {
	private Float nota;
	private Disciplina disciplina;
	private Aluno aluno;
	
	public Avaliacao(Float nota, Disciplina disciplina, Aluno aluno) {
		super();
		this.nota = nota;
		this.disciplina = disciplina;
		this.aluno = aluno;
	}

	public Disciplina getDisciplina() {
		return disciplina;
	}
	
	public Float getNota() {
		return nota;
	}
	
	public Aluno getAluno() {
		return aluno;
	}

}
