package acadêmico;

public class Disciplina {
		private String nome;
		
		public Disciplina(String nome) {
			super();
			this.nome = nome;
		}

		public String getNome() {
			return nome;
		}

}
