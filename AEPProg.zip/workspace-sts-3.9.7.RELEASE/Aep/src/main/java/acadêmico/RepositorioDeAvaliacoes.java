package acadêmico;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RepositorioDeAvaliacoes {
private List<Avaliacao> avaliacoes = new ArrayList<Avaliacao>();
	
	public RepositorioDeAvaliacoes() {
	}

	public void adicionarAvaliacao(Avaliacao avaliacao) {
		avaliacoes.add(avaliacao);
	}
	
	public List<Aluno> obterAprovados(Disciplina disciplina, boolean print) {
		List<Avaliacao> avaliacoes = obterAvaliacoesPorDisciplina(disciplina);
		List<Aluno> alunos = obterAlunos(disciplina);
		List<Aluno> alunosAprovados = new ArrayList<Aluno>();
		Float soma;
		
		for (Aluno aluno: alunos) {
			soma = 0f;
			for (Avaliacao avaliacao: avaliacoes) {
				if (avaliacao.getAluno() == aluno) soma += avaliacao.getNota();
			}
			if (soma / 4 >= 6) {
				alunosAprovados.add(aluno);
				if (print) System.out.println("Aprovado: " + aluno.getNome());
			}
		}
		
		return alunosAprovados;
	}
	
	public List<Avaliacao> obterAvaliacoesPorDisciplina(Disciplina disciplina) {
		List<Avaliacao> avaliacoesDaDiscplina = new ArrayList<Avaliacao>();
		
		for (int i = 0; i < avaliacoes.size(); i++) {
			if (avaliacoes.get(i).getDisciplina() == disciplina) avaliacoesDaDiscplina.add(avaliacoes.get(i));
		}
		
		return avaliacoesDaDiscplina;
	}
	
	public List<Aluno> obterAlunos(Disciplina disciplina) {
		Set<Aluno> alunosDeAvaliacoes = new HashSet<Aluno>();
		List<Aluno> alunosDeAvaliacoesList = new ArrayList<Aluno>();
		
		for (Avaliacao avaliacao: obterAvaliacoesPorDisciplina(disciplina)) alunosDeAvaliacoes.add(avaliacao.getAluno());
		for (Aluno aluno: alunosDeAvaliacoes) alunosDeAvaliacoesList.add(aluno);
		
		return alunosDeAvaliacoesList;
	}


}
